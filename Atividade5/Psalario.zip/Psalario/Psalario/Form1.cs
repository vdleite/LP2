﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salBruto, numFilhos, descINSS, descIRPF, salFamiliar, salLiquido;

        private void txtNome_Validated(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Campo de preenchimento obrigatório.");
                txtNome.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //AlqINSS
            if (!double.TryParse(mskbxSalBruto.Text, out salBruto))
                {
                
            }
            else
                {
                numFilhos = Convert.ToDouble(nupFilhos.Value);

                if (salBruto <= 800.47)
                {
                    txtAlqINSS.Text = "7,65%";
                    descINSS = (salBruto * 0.0765);
                    txtDescINSS.Text = descINSS.ToString();
                }
                else if (salBruto <= 1050)
                {
                    txtAlqINSS.Text = "8.65%";
                    descINSS = (salBruto * 0.0865);
                    txtDescINSS.Text = descINSS.ToString();
                }
                else if (salBruto <= 1400.77)
                {
                    txtAlqINSS.Text = "9.00%";
                    descINSS = (salBruto * 0.09);
                    txtDescINSS.Text = descINSS.ToString();
                }
                else if (salBruto <= 2801.56)
                {
                    txtAlqINSS.Text = "11.00%";
                    descINSS = (salBruto * 0.11);
                    txtDescINSS.Text = descINSS.ToString();
                }
                else
                {
                    txtAlqINSS.Text = "Teto";
                    descINSS = 308.17;
                    txtDescINSS.Text = "308.17";
                }
                //AlqIRPF
                if (salBruto <= 1257.12)
                {
                    txtAlqIRPF.Text = "Isento";
                    descIRPF = 0;
                    txtDescIRPF.Text = descIRPF.ToString();
                }
                else if (salBruto <= 2512.08)
                {
                    txtAlqIRPF.Text = "15,00%";
                    descIRPF = (salBruto * 0.15);
                    txtDescIRPF.Text = descIRPF.ToString();
                }
                else
                {
                    txtAlqIRPF.Text = "27.5%";
                    descIRPF = (salBruto * 0.275);
                    txtDescIRPF.Text = descIRPF.ToString();
                }

                //salFamiliar
                if (salBruto <= 435.52)
                {
                    salFamiliar = (numFilhos * 22.33);
                    txtSalFamiliar.Text = salFamiliar.ToString();
                }
                else if (salBruto <= 654.61)
                {
                    salFamiliar = (numFilhos * 15.74);
                    txtSalFamiliar.Text = salFamiliar.ToString();
                }
                else
                {
                    salFamiliar = 0;
                    txtSalFamiliar.Text = salFamiliar.ToString();
                }

                //salLiquido
                salLiquido = salBruto - descINSS - descIRPF + salFamiliar;
                txtSalLiquido.Text = salLiquido.ToString();
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber (e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Apenas Letras.");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }


        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAlqINSS.Text = "";
            txtAlqIRPF.Text = "";
            txtDescINSS.Text = "";
            txtDescIRPF.Text = "";
            txtNome.Text = "";
            txtSalFamiliar.Text = "";
            txtSalLiquido.Text = "";
            nupFilhos.Value = 0;
            txtNome.Focus();
        }
    }
}
