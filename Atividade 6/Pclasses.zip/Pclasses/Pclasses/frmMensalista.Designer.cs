﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninstanciar1 = new System.Windows.Forms.Button();
            this.btninstanciar2 = new System.Windows.Forms.Button();
            this.txtdataEntradaempresa = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btninstanciar1
            // 
            this.btninstanciar1.Location = new System.Drawing.Point(35, 191);
            this.btninstanciar1.Margin = new System.Windows.Forms.Padding(2);
            this.btninstanciar1.Name = "btninstanciar1";
            this.btninstanciar1.Size = new System.Drawing.Size(121, 53);
            this.btninstanciar1.TabIndex = 0;
            this.btninstanciar1.Text = "Instanciar Mensalista";
            this.btninstanciar1.UseVisualStyleBackColor = true;
            this.btninstanciar1.Click += new System.EventHandler(this.btninstanciar1_Click);
            // 
            // btninstanciar2
            // 
            this.btninstanciar2.Location = new System.Drawing.Point(183, 191);
            this.btninstanciar2.Margin = new System.Windows.Forms.Padding(2);
            this.btninstanciar2.Name = "btninstanciar2";
            this.btninstanciar2.Size = new System.Drawing.Size(121, 53);
            this.btninstanciar2.TabIndex = 1;
            this.btninstanciar2.Text = "Instanciar Mensalista passando parâmetros";
            this.btninstanciar2.UseVisualStyleBackColor = true;
            this.btninstanciar2.Click += new System.EventHandler(this.btninstanciar2_Click);
            // 
            // txtdataEntradaempresa
            // 
            this.txtdataEntradaempresa.Location = new System.Drawing.Point(183, 124);
            this.txtdataEntradaempresa.Margin = new System.Windows.Forms.Padding(2);
            this.txtdataEntradaempresa.Name = "txtdataEntradaempresa";
            this.txtdataEntradaempresa.Size = new System.Drawing.Size(125, 20);
            this.txtdataEntradaempresa.TabIndex = 2;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(183, 87);
            this.txtSalarioMensal.Margin = new System.Windows.Forms.Padding(2);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(125, 20);
            this.txtSalarioMensal.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(183, 55);
            this.txtNome.Margin = new System.Windows.Forms.Padding(2);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(348, 20);
            this.txtNome.TabIndex = 4;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(183, 27);
            this.txtMatricula.Margin = new System.Windows.Forms.Padding(2);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(68, 20);
            this.txtMatricula.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Matrícula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 59);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 91);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Salário Mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 124);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Data Entrada na Empresa";
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 292);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtdataEntradaempresa);
            this.Controls.Add(this.btninstanciar2);
            this.Controls.Add(this.btninstanciar1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btninstanciar1;
        private System.Windows.Forms.Button btninstanciar2;
        private System.Windows.Forms.TextBox txtdataEntradaempresa;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}