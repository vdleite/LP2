﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    internal class Horista : Empregado
    {
        public double SalHora { get; set; }
        public double NumHora { get; set; }
        public int Faltas { get; set; }
        public override double SalBruto()
        {
        return SalHora * NumHora;
        }
        public override int TempoTrab()
        {
            TimeSpan span =
                DateTime.Today.Subtract(DataEntradaEmpresa);
            return (Convert.ToInt32(span.Days - Faltas));
        }
    }
}
