﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace pDisaster
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection Connection;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                Connection = new SqlConnection("Data Source = apolo; Initial Catalog = LP2; User ID = bd2321013; PASSWORD = SbIsGood765; Encrypt = False");
                Connection.Open();
            }
            catch (SqlException ex) 
            {
                MessageBox.Show("Erro de banco de dados :c" + ex.Message);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Outros erros :C" + ex.Message);
            }
        }

        private void tiposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmTipo>().Count() > 0) 
            {
                Application.OpenForms["frmTipo"].BringToFront();
            }
            else
            {
                frmTipo objFrm2 = new frmTipo();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }

        private void cidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade objFrm2 = new frmCidade();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre objFrm2 = new frmSobre();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }

        private void eventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEvento>().Count() > 0)
            {
                Application.OpenForms["frmEvento"].BringToFront();
            }
            else
            {
                frmEvento objFrm2 = new frmEvento();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }
        }
    }
}
