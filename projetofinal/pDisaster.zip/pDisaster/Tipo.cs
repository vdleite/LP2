﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace pDisaster
{
    internal class Tipo
    {
        public int IdTipo { get; set; }
        public string Descricao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("select * from Tipo order by idtipo", frmPrincipal.Connection);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtCidade;
        }

        public int Incluir()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("insert into Tipo values" + "(@Descricao)", frmPrincipal.Connection);
                mycommand.Parameters.Add(new SqlParameter("@Descricao", SqlDbType.Char));

                mycommand.Parameters["@Descricao"].Value = Descricao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("UPDATE Tipo SET " +
                    "Descricao=@Descricao " + "WHERE IDTipo=@IDTipo", frmPrincipal.Connection);



                mycommand.Parameters.Add(new SqlParameter("@IDTipo", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@Descricao", SqlDbType.VarChar));

                mycommand.Parameters["@IDTIpo"].Value = IdTipo;

                mycommand.Parameters["@Descricao"].Value = Descricao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Excluir()
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM Tipo WHERE IDTipo=@IDTipo", frmPrincipal.Connection);

                mycommand.Parameters.Add(new SqlParameter("@IDTipo", SqlDbType.Int));
                mycommand.Parameters["@IDTipo"].Value = IdTipo;

                nReg = mycommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
    }
}
