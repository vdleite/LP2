﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }


        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultados.Text = resultado.ToString();
        }


        private void btnSubtrai_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultados.Text = resultado.ToString();
        }


        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultados.Text = resultado.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            resultado = numero1 / numero2;
            txtResultados.Text = resultado.ToString();
        }

        private void txtNumero2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtNumero2.Text, out numero2))
            {
                lblAlerta.Text = "Valor inválido";
                e.Cancel = true;
            }
            else
            {
                lblAlerta.Text = "";
            }

        }

        private void txtNumero1_Validating(object sender, CancelEventArgs e)
        {

            if (!double.TryParse(txtNumero1.Text, out numero1))
            {
                lblAlerta.Text = "Valor inválido";
                e.Cancel = true;
            }
            else
            {
                lblAlerta.Text = "";
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            txtResultados.Text = "";
            txtNumero1.Focus();
            resultado = 0;
        }
    }

}
